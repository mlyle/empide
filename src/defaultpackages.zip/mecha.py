import machine
import esp32
import time

i2c = None

def init_i2c():
    global i2c
    
    if i2c is None:
        i2c = machine.SoftI2C(scl=machine.Pin(22), sda=machine.Pin(21))
        
class IMU_Sample:
    def bytes_toint(self, firstbyte, secondbyte):
        if not firstbyte & 0x80:
            return firstbyte << 8 | secondbyte
        return - (((firstbyte ^ 255) << 8) | (secondbyte ^ 255) + 1)
        
    def bytes_toaccel(self, firstbyte, secondbyte):
        return self.bytes_toint(firstbyte, secondbyte) / 16384.0

    def bytes_torot(self, firstbyte, secondbyte):
        return self.bytes_toint(firstbyte, secondbyte) / 131.072

    def __init__(self, raw_ints):
        self.x = self.bytes_toaccel(raw_ints[0], raw_ints[1])
        self.y = self.bytes_toaccel(raw_ints[2], raw_ints[3])
        self.z = self.bytes_toaccel(raw_ints[4], raw_ints[5])
        self.temp = self.bytes_toint(raw_ints[6], raw_ints[7]) / 340.00 + 36.53
        self.p = self.bytes_torot(raw_ints[8], raw_ints[9])
        self.q = self.bytes_torot(raw_ints[10], raw_ints[11])
        self.r = self.bytes_torot(raw_ints[12], raw_ints[13])

    def __repr__(self):
        rep = 'IMU_Sample('
        
        names = ('x', 'y', 'z', 'temp', 'p', 'q', 'r')
        values = (self.x, self.y, self.z, self.temp, self.p, self.q, self.r)
        
        reps = []
        
        for i in range(len(names)):
            reps.append(names[i] + '=' + "{:5.2f}".format(values[i]))
            
        rep += ', '.join(reps)
        
        rep += ')'
        
        return rep
        
class IMU:
    def __init__(self, addr=0x68):
        init_i2c()
        
        self.addr = addr
        
        i2c.start()
        i2c.writeto(self.addr, bytearray([107, 0]))
        i2c.stop()

    def get_raw_values(self, discard=True):
        if discard:
            i2c.start()
            i2c.readfrom_mem(self.addr, 0x3B, 14)
            i2c.stop()

        i2c.start()
        a = i2c.readfrom_mem(self.addr, 0x3B, 14)
        i2c.stop()
        return a

    def get_values(self):
        return IMU_Sample(self.get_raw_values())
        
imu = IMU()

class Servo:
    def __init__(self, pin_number = 32):
        self.pin = machine.Pin(pin_number)
        self.inited = False
        self.position = -1
        
    def set_position(self, position):
        if position < 0.0:
            position = 0.0

        if position > 1.0:
            position = 1.0
        duty = int(position * 100 + 23)

        if not self.inited:
            self.PWM = machine.PWM(self.pin, 50)

        self.PWM.duty(duty)
        self.position = position
    
    def get_position(self):
        return self.position

servo1 = Servo(17)
servo2 = Servo(18)
servo3 = Servo(26)

class LED:
    def __init__(self, pin_number):
        self.pwm = machine.PWM(machine.Pin(pin_number), 20000)
        self.off()

    def off(self):
        self.brightness(0)

    
    def on(self):
        self.brightness(1.0)
        
    def brightness(self, bright):
        if bright < 0.0:
            bright = 0.0
        
        if bright > 1.0:
            bright = 1.0
            
        self.pwm.duty(int(1023 * pow(bright, 3)))

led = LED(2)

class Touch:
    def __init__(self, pin):
        self.touch = machine.TouchPad(machine.Pin(pin))
    
    def read(self):
        return self.touch.read()
        
    def touched(self):
        return self.read() < 400

touchpads = ( Touch(13), Touch(12), Touch(14), Touch(27), Touch(33) )

def readtouches():
    return tuple([ a.read() for a in touchpads ])

class TouchSlider:
    def __init__(self, touchpads, threshold=240):
        self.touchpads = touchpads
        self.threshold = threshold

    def read(self):
        values = [ a.read() for a in self.touchpads ]

        smallest_val = 1000
        smallest_idx = 0

        for i in range(len(values)):
            if values[i] < smallest_val:
                smallest_val = values[i]
                smallest_idx = i

        if smallest_val > self.threshold:
            return -1

        if smallest_idx != len(values)-1:
            right_side = values[smallest_idx+1]
        else:
            right_side = 1000

        if smallest_idx != 0:
            left_side = values[smallest_idx-1]
        else:
            left_side = 1000

        adjustment = 0.0

        # Overall logic here:  if the 2 pads are equally good, you'll move halfway there
        offset = self.threshold - smallest_val

        if left_side < right_side:
            if left_side < self.threshold:
                side_offset = self.threshold - left_side

                adjustment = (-0.5 * side_offset) / offset
        else:
            if right_side < self.threshold:
                side_offset = self.threshold - right_side

                adjustment = (0.5 * side_offset) / offset

        return (smallest_idx+adjustment) / (len(values)-1)

slider = TouchSlider(touchpads)

def LEDString(pin_number = 19, num_leds=4):
    import mechaneopixel
    
    return mechaneopixel.Pixels(machine.Pin(pin_number, machine.Pin.OUT), num_leds)

def get_magnet():
    return esp32.hall_sensor()

def OLED():
    import ssd1306
    init_i2c()
    return ssd1306.SSD1306_I2C(128, 64, i2c)
